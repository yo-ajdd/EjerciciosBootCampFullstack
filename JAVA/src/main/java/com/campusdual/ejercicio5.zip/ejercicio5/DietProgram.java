package com.campusdual.ejercicio5;

import com.campusdual.ejercicio5.enums.Days;
import com.campusdual.ejercicio5.exceptions.MaxCaloriesReachedException;
import com.campusdual.ejercicio5.exceptions.MaxCarbsReachedException;
import com.campusdual.ejercicio5.exceptions.MaxFatsReachedException;
import com.campusdual.ejercicio5.exceptions.MaxProteinsReachedException;

import java.util.ArrayList;
import java.util.List;

public class DietProgram {

    public static final Boolean ADD_TEST_DATA = true;

    // Almacena la lista de alimentos
    private List<Food> foodList;
    // Creo un hashmap para la lista de dietas
    private List<Diet> dietList;
    private List<Customer> customerList;

    public DietProgram() {
        foodList = new ArrayList<>();
        dietList = new ArrayList<>();
        customerList = new ArrayList<>();
    }


    public void showMenuProgram() {
        if (ADD_TEST_DATA) {
            insertDummyFood();
            insertDummyDiet();
            insertDummyCustomer();
        }
        System.out.println("########################################################");
        System.out.println("################# Programa de Menús ###################");
        System.out.println("########################################################");
        Integer option;
        do {
            System.out.println("Escriba una opción:");
            System.out.println("===================================");
            System.out.println("1-Gestión de Dietas");
            System.out.println("2-Gestión de Pacientes");
            System.out.println("3-Salir");
            option = Kb.getOption(1, 3);
            switch (option) {
                case 1:
                    dietManage();
                    break;
                case 2:
                    customerManage();
                    break;
                case 3:
                    System.out.println("Gracias por usar el programa, hasta pronto :)");
                    break;
            }
        } while (option != 3);
    }

    private void dietManage() {
        Integer option;
        do {
            System.out.println("########################################################");
            System.out.println("################# Gestión de Dietas ###################");
            System.out.println("########################################################");
            System.out.println("Escriba una opción:");
            System.out.println("===================================");
            System.out.println("1-Agregar nueva dieta");
            System.out.println("2-Listar Dietas");
            System.out.println("3-Eliminar Dieta");
            System.out.println("4-Volver");
            option = Kb.getOption(1, 4);
            switch (option) {
                case 1:
                    dietCreate();
                    break;
                case 2:
                    dietShow();
                    break;
                case 3:
                    dietRemove();
                case 4:
                    break;
            }
        } while (option != 4);
    }

    private void dietCreate() {
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        System.out.println("Crear/reiniciar dieta");
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        Boolean validDietName;
        String dietName;
        do {
            System.out.println("Introduzca un nombre para la dieta:");
            dietName = Kb.nextLine();
            validDietName = !dietList.contains(dietName);
            if (!validDietName) {
                System.out.println("Ya existe una dieta con ese nombre");
            }
        } while (!validDietName);

        System.out.println("Escriba una opción:");
        System.out.println("===================================");
        System.out.println("1-Dieta sin límite");
        System.out.println("2-Dieta por calorías");
        System.out.println("3-Dieta por macronutrientes");
        System.out.println("4-Dieta por datos personales");
        Integer option = Kb.getOption(1, 4);
        switch (option) {
            case 1:
                dietList.add(new Diet(dietName));
                System.out.println("Se ha creado una dieta sin límites");
                break;
            case 2:
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Escriba número de calorias");
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                Integer calories = Kb.forceNextInt();
                dietList.add(new Diet(dietName,calories));
                System.out.println("Se ha creado una dieta con " + calories + " calorías máximas");
                break;
            case 3:
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Escriba los macronutrientes");
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Carbohidratos:");
                Integer carbs = Kb.forceNextInt();
                System.out.println("Grasas:");
                Integer fats = Kb.forceNextInt();
                System.out.println("Proteínas:");
                Integer proteins = Kb.forceNextInt();
                dietList.add(new Diet(dietName,fats, carbs, proteins));
                System.out.println("Se ha creado una dieta con Carbohidratos:" + carbs + ", Grasas:" + fats + " ,Proteínas:" + proteins);
                break;
            case 4:
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Escriba los datos personales del paciente");
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Peso:");
                Integer weight = Kb.forceNextInt();
                System.out.println("Altura:");
                Integer height = Kb.forceNextInt();
                System.out.println("Edad:");
                Integer age = Kb.forceNextInt();
                System.out.println("Mujer u Hombre(m/h):");
                String sexCharacter = Kb.nextLine();
                Diet newDiet = new Diet(dietName,"m".equalsIgnoreCase(sexCharacter), age, height, weight);
                dietList.add(newDiet);
                System.out.println("Se ha creado una dieta de " + newDiet.getMaxCalories() + " calorías máximas");
                break;
        }
    }

    private void dietShow() {
        Diet diet = getSelectedDiet();
        if (diet == null) {
            System.out.println("Elemento no encontrado");
            return;
        }
        Integer option;
        Integer userdata;
        do {
            showDetailsMenu(diet);
            System.out.println("1-Cambiar calorias máx.");
            System.out.println("2-Cambiar carbohidratos máx.");
            System.out.println("3-Cambiar grasa máx.");
            System.out.println("4-Cambiar proteinas máx.");
            System.out.println("5-Añadir alimento");
            System.out.println("6-Volver");
            option = Kb.getOption(1, 6);
            if (option >= 1 && option <= 4) {
                updateDiet(diet, option);
            } else if (option == 5) {
                addFoodMenu(diet);
            }
        } while (option != 6);
    }

    private void dietRemove() {
        // Vuelve un nombre de dieta....
        Diet diet = getSelectedDiet();
        if (diet == null) {
            System.out.println("Elemento no encontrado");
        } else {
            // Borro la dieta solo si no está asignada
            if (dietAssigned(diet.getName())) {
                System.out.println("La dieta está asignada a un paciente. No se puede eliminar");
                return;
            }
            dietList.remove(diet);
        }
    }

    private void customerManage() {
        Integer option;
        do {
            System.out.println("########################################################");
            System.out.println("################# Gestión de Pacientes #################");
            System.out.println("########################################################");
            System.out.println("Escriba una opción:");
            System.out.println("===================================");
            System.out.println("1-Nuevo Paciente");
            System.out.println("2-Listar Pacientes");
            System.out.println("3-Eliminar Paciente");
            System.out.println("4-Volver");
            option = Kb.getOption(1, 4);
            switch (option) {
                case 1:
                    customerCreate();
                    break;
                case 2:
                    customerShow();
                    break;
                case 3:
                    customerRemove();
                case 4:
                    break;
            }
        } while (option != 4);

    }

    private void customerCreate() {
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        System.out.println("Escriba los datos personales del paciente");
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        System.out.println("Nombre:");
        String name = Kb.nextLine();
        System.out.println("Apellidos:");
        String surname = Kb.nextLine();
        System.out.println("Peso:");
        Integer weight = Kb.forceNextInt();
        System.out.println("Altura:");
        Integer height = Kb.forceNextInt();
        System.out.println("Edad:");
        Integer age = Kb.forceNextInt();
        System.out.println("Mujer u Hombre(m/h):");
        String sexCharacter = Kb.nextLine();
        Customer newCustomer = new Customer(name, surname, weight, height, age, sexCharacter);
        customerList.add(newCustomer);
        System.out.println("Cliente creado");
    }

    private void customerShow() {
        Customer customer = getSelectedCustomer();
        if (customer == null) {
            System.out.println("Elemento no encontrado");
        } else {
            Integer option;
            Integer i;
            System.out.println(customer.getCustomerDetails());
            System.out.println(" -- DIETAS --");
            for (i = 1; i < 8; i++) {
                System.out.print(Days.getByPosition(i).getName() + "-");
                if (customer.getCustomerDiets().get(i - 1) == null) {
                    System.out.println("");
                } else {
                    System.out.println(customer.getCustomerDiets().get(i - 1));
                }
            }
            System.out.println("1-Cambiar Nombre");
            System.out.println("2-Cambiar Apellidos");
            System.out.println("3-Cambiar Peso");
            System.out.println("4-Cambiar Altura");
            System.out.println("5-Cambiar Edad");
            System.out.println("6-Cambiar Sexo");
            System.out.println("7-Agregar Dieta");
            System.out.println("8-Eliminar Dieta");
            System.out.println("9-Volver");
            option = Kb.getOption(1, 9);
            if (option >= 1 && option <= 6) {
                customerUpdate(customer, option);
            } else if (option == 7) {
                customerAddDiet(customer);
            } else if (option == 8) {
                customerRemoveDiet(customer);
            }
        }
    }

    private void customerRemove() {
        Customer customer = getSelectedCustomer();
        if (customer == null) {
            System.out.println("Elemento no encontrado");
        } else {
            // Borro la dieta
            customerList.remove(customer);
        }
    }

    private void customerUpdate(Customer customer, Integer option) {
        Integer userdataInt;
        String userdataStr;
        System.out.println("Introduce nuevo valor:");
        switch (option) {
            case 1:
                userdataStr = Kb.nextLine();
                customer.setName(userdataStr);
                break;
            case 2:
                userdataStr = Kb.nextLine();
                customer.setSurname(userdataStr);
                break;
            case 3:
                userdataInt = Kb.nextInt();
                customer.setWeight(userdataInt);
                break;
            case 4:
                userdataInt = Kb.nextInt();
                customer.setHeight(userdataInt);
                break;
            case 5:
                userdataInt = Kb.nextInt();
                customer.setAge(userdataInt);
                break;
            case 6:
                userdataStr = Kb.nextLine();
                customer.setGender(userdataStr);
                break;

        }
    }

    private void customerRemoveDiet(Customer customer) {
        Days day = getSelectedDay();
        if (day == null) {
            System.out.println("Dato no válido");
            return;
        }
        customer.getCustomerDiets().remove(day.getPosition());
        System.out.println("Dieta eliminada");
    }

    private void customerAddDiet(Customer customer) {
        Diet diet = getSelectedDiet();
        if (dietname == null) {
            System.out.println("Elemento no encontrado");
        } else {
            // Tengo la dieta, necesito el dia de la semana
            Days day = getSelectedDay();
            if (day == null) {
                System.out.println("Dato no válido");
                return;
            }
            customer.getCustomerDiets().put(day.getPosition(), diet.getName());
            System.out.println("Dieta añadida al paciente");
        }
    }

    // ==========================================


    private boolean dietAssigned(String dietNameSearch) {
        Boolean assigned;
        for (Customer customer : customerList) {
            for (String dietName : customer.getCustomerDiets().values()) {
                if (dietName.equalsIgnoreCase(dietNameSearch)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void updateDiet(Diet diet, Integer option) {
        Integer userdata;
        System.out.println("Introduce nuevo valor:");
        userdata = Kb.nextInt();
        switch (option) {
            case 1:
                diet.setMaxCalories(userdata);
                break;
            case 2:
                diet.setMaxCarbs(userdata);
                break;
            case 3:
                diet.setMaxFats(userdata);
                break;
            case 4:
                diet.setMaxProteins(userdata);
                break;
            case 5:
                addFoodMenu(diet);
                break;
        }
    }

    private Diet getSelectedDiet() {
        if (dietList.size() == 0) {
            System.out.println("No existen dietas");
        }
        // tengo dietas asi que necesito sus keys
        System.out.println("Escoja una dieta:");
        Integer option = 1;
        for (Diet diet : dietList) {
            System.out.println(option + "-" + diet.getName());
            option++;
        }
        System.out.println(option + "-Volver");
        Integer selected = Kb.getOption(1, option);
        if (selected == option) {
            return null;
        } else {
            return dietList.get(selected - 1);
        }
    }

    private Customer getSelectedCustomer() {
        if (customerList.size() == 0) {
            System.out.println("No existen pacientes");
        }
        // tengo pacientes asi que los listo
        System.out.println("Escoja un paciente:");
        Integer option = 1;
        for (Customer customer : customerList) {
            System.out.println(option + "-" + customer.getName() + " " + customer.getSurname());
            option++;
        }
        System.out.println(option + "-Volver");
        Integer selected = Kb.getOption(1, option);
        if (selected == option) {
            return null;
        } else {
            return customerList.get(selected - 1);
        }
    }

    private Days getSelectedDay() {
        System.out.println("Escoja un día de la semana:");
        Integer option = 1;
        for (Days day : Days.values()) {
            System.out.println(option + "-" + day.getName());
            option++;
        }
        System.out.println(option + "-Volver");
        Integer selected = Kb.getOption(1, option);
        if (selected == option) {
            return null;
        } else {
            return Days.getByPosition(selected - 1);
        }
    }


    private void addFoodMenu(Diet diet) {
        if (diet == null) {
            System.out.println("Para agregar alimentos hace falta iniciar una dieta");
            return;
        }
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        System.out.println("Agregar Alimentos a la dieta");
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        System.out.println("Escriba una opción:");
        System.out.println("===================================");
        System.out.println("1-Agregar un nuevo alimento");
        System.out.println("2-Agregar un alimento ya existente");

        Integer option = Kb.getOption(1, 2);
        switch (option) {
            case 1:
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Datos de nuevo alimento");
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Nombre del alimento:");
                String name = Kb.nextLine();
                System.out.println("Carbohidratos:");
                Integer carbs = Kb.forceNextInt();
                System.out.println("Grasas:");
                Integer fats = Kb.forceNextInt();
                System.out.println("Proteínas:");
                Integer proteins = Kb.forceNextInt();
                System.out.println("Gramos:");
                Integer grams = Kb.forceNextInt();
                Food newFood = new Food(name, carbs, fats, proteins);
                validateAndAddFoodToDiet(diet, newFood, grams);
                foodList.add(newFood);
                break;
            case 2:
                if (foodList.size() == 0) {
                    System.out.println("Para agregar un alimento existente, tienen que existir alimentos previos");
                    return;
                }
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                System.out.println("Escoja un alimento");
                System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                Integer i = 1;
                for (Food food : foodList) {
                    System.out.println(i + "- " + food.getName());
                    i++;
                }
                System.out.println(i + "- Cancelar");
                Integer element = Kb.getOption(1, i);
                if (element == i) {
                    System.out.println("Cancelando alimento");
                    return;
                }
                Food storedFood = foodList.get(element - 1);
                System.out.println("indique el número de gramos de " + storedFood.getName());
                Integer foodGrams = Kb.forceNextInt();
                validateAndAddFoodToDiet(diet, storedFood, foodGrams);
                break;
        }
    }

    private void validateAndAddFoodToDiet(Diet diet, Food food, Integer grams) {
        try {
            diet.addFood(food, grams);
        } catch (MaxCaloriesReachedException ecal) {
            System.out.println("Se ha alcanzado el máximo valor de calorías permitido");
        } catch (MaxCarbsReachedException ecar) {
            System.out.println("Se ha alcanzado el máximo valor de carbohidratos permitido");
        } catch (MaxFatsReachedException efat) {
            System.out.println("Se ha alcanzado el máximo valor de grasas permitido");
        } catch (MaxProteinsReachedException epro) {
            System.out.println("Se ha alcanzado el máximo valor de proteínas permitido");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void showDetailsMenu(Diet diet) {
        if (diet != null) {
            System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            System.out.println("Detalles de la dieta");
            System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            if (diet.getMaxCalories() != null) {
                System.out.println("El número máximo de calorías es:" + diet.getMaxCalories());
            }
            if (diet.getMaxCarbs() != null || diet.getMaxFats() != null || diet.getMaxProteins() != null) {
                System.out.println("Los valores máximos de macronutrientes son: Carbohidratos:" + diet.getMaxCarbs() + " , Grasas:" + diet.getMaxFats() + " , Proteinas:" + diet.getMaxProteins());
            }
            System.out.println("Número de alimentos de la dieta:" + diet.getFoodNumber());
            System.out.println("Calorías:" + diet.getTotalCalories());
            System.out.println("Carbohidratos:" + diet.getTotalCarbs());
            System.out.println("Grasas:" + diet.getTotalFats());
            System.out.println("Proteínas:" + diet.getTotalProteins());
            System.out.println("Alimentos de la dieta:" + diet.getDietIntakes());
        } else {
            System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            System.out.println("La dieta no esta iniciada");
            System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        }
    }

    // MIS COSAS

    private void insertDummyFood() {

        Food food = new Food("a1", 10, 20, 30);
        foodList.add(food);

        food = new Food("a1", 20, 30, 40);
        foodList.add(food);

        food = new Food("a2", 30, 40, 50);
        foodList.add(food);

        System.out.println(">> Alimentos de prueba añadidos a la dieta");
    }

    private void insertDummyDiet() {

        Diet diet = new Diet();
        dietList.put("dieta no limite", diet);

        diet = new Diet(2000);
        dietList.put("dieta calorias", diet);

        diet = new Diet(100, 200, 300);
        dietList.put("dieta macros", diet);

        System.out.println(">> Dietas de prueba creadas");
    }

    private void insertDummyCustomer() {

        Customer customer = new Customer("pac1", "ape1", 70, 160, 30, "h");
        customer.getCustomerDiets().put(5, "dieta no limite");
        customerList.add(customer);
        customerList.add(new Customer("pac2", "ape2", 70, 160, 30, "h"));
        customerList.add(new Customer("pac3", "ape3", 50, 170, 20, "m"));

        System.out.println(">> Pacientes de prueba creados");
    }
}
