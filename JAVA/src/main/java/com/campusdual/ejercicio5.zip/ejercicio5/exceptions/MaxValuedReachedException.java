package com.campusdual.ejercicio5.exceptions;

public abstract class MaxValuedReachedException extends Exception {
    public MaxValuedReachedException(String msg){
        super(msg);
    }
}
